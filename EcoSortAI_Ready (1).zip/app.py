import streamlit as st
import google.generativeai as genai

st.set_page_config(page_title="EcoSort AI", page_icon="♻️", layout="wide")

GEMINI_API_KEY = st.secrets["GEMINI_API_KEY"]
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel("gemini-2.5-flash")

st.title("♻️ EcoSort AI")
st.subheader("Asisten Cerdas Pemilahan Sampah Rumah Tangga")

st.markdown("""
### Mengapa Pemilahan Sampah Penting?
EcoSort AI membantu masyarakat mengenali jenis sampah dan cara pengelolaannya menggunakan AI.
""")

st.header("🔍 Tanya AI tentang Sampah")

user_input = st.text_input(
    "Masukkan nama sampah atau deskripsinya:",
    placeholder="Contoh: botol parfum bekas"
)

if st.button("Analisis dengan AI"):
    if user_input:
        prompt = f"""
        Anda adalah ahli pengelolaan sampah dan lingkungan.

        Sampah: {user_input}

        Berikan jawaban dengan format:
        1. Jenis Sampah
        2. Apakah Bisa Didaur Ulang?
        3. Cara Pengelolaan yang Benar
        4. Dampak Lingkungan Jika Dibuang Sembarangan
        5. Tips Pengurangan Sampah
        """
        with st.spinner("AI sedang menganalisis..."):
            response = model.generate_content(prompt)
            st.success("Analisis selesai")
            st.markdown(response.text)
    else:
        st.warning("Silakan masukkan jenis sampah terlebih dahulu.")

st.divider()
st.caption("Dibuat untuk Proyek Akhir Basic AI - Program Perempuan Inovasi x IBM SkillsBuild")
